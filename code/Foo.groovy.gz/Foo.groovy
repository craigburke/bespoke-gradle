class Foo {
    String bar = 'WUT'
}